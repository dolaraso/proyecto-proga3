package com.cybersentinels.vista;

import com.cybersentinels.dao.UsuarioDAO;
import com.cybersentinels.modelo.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class GestionUsuariosWindow {
    private JPanel panelPrincipal; // Panel principal
    private JTable tableUsuarios; // Tabla de usuarios
    private JButton btnAgregar; // Botón para agregar un nuevo usuario
    private JButton btnModificar; // Botón para editar un usuario seleccionado
    private JButton btnEliminar; // Botón para borrar un usuario seleccionado
    private JButton btnBuscar; // Botón para buscar usuarios
    private JTextField txtBuscarUsuario;
    private UsuarioDAO usuarioDAO; // DAO para interactuar con la base de datos

    public GestionUsuariosWindow() {
        usuarioDAO = new UsuarioDAO();
        initializeComponents(); // Inicializar componentes
        cargarUsuariosEnTabla(usuarioDAO.obtenerUsuarios()); // Cargar datos en la tabla al inicio

        // Acción para el botón "agregar"
        btnAgregar.addActionListener(e -> agregarUsuario());

        // Acción para el botón "modificar"
        btnModificar.addActionListener(e -> editarUsuario());

        // Acción para el botón "Borrar"
        btnEliminar.addActionListener(e -> eliminarUsuario());

        // Acción para el botón "Buscar" (puedes implementar la lógica de búsqueda más adelante)
        btnBuscar.addActionListener(e -> JOptionPane.showMessageDialog(null, "Funcionalidad de búsqueda en desarrollo."));
    }

    /**
     * Inicializa los componentes necesarios de la ventana.
     */
    private void initializeComponents() {
        if (tableUsuarios == null) {
            tableUsuarios = new JTable(); // Crear la instancia de la tabla si no está inicializada
        }

        // Configurar el modelo de la tabla
        tableUsuarios.setModel(new DefaultTableModel(
                new Object[][]{}, // Datos iniciales vacíos
                new String[]{"ID", "Nombre", "Usuario", "Rol"} // Encabezados de las columnas
        ));
    }

    /**
     * Carga los usuarios en la tabla.
     */
    public void cargarUsuariosEnTabla(List<Usuario> usuarios) {
        DefaultTableModel model = (DefaultTableModel) tableUsuarios.getModel();
        model.setRowCount(0); // Limpia las filas existentes
        for (Usuario usuario : usuarios) {
            model.addRow(new Object[]{usuario.getId(), usuario.getNombre(), usuario.getUsuario(), usuario.getRol()});
        }
    }

    /**
     * Abre la ventana para agregar un nuevo usuario.
     */
    private void agregarUsuario() {
        AgregarUsuarioWindow agregarUsuarioWindow = new AgregarUsuarioWindow();
        JFrame frame = new JFrame("Agregar Usuario");
        frame.setContentPane(agregarUsuarioWindow.getPanelPrincipal());
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                cargarUsuariosEnTabla(usuarioDAO.obtenerUsuarios()); // Recargar la tabla después de agregar
            }
        });
    }

    /**
     * Abre la ventana para editar un usuario seleccionado.
     */
    private void editarUsuario() {
        int selectedRow = tableUsuarios.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione un usuario para editar.");
            return;
        }

        int usuarioId = (int) tableUsuarios.getValueAt(selectedRow, 0);
        Usuario usuario = usuarioDAO.obtenerUsuarioPorId(usuarioId);

        if (usuario != null) {
            EditarUsuarioWindow editarUsuarioWindow = new EditarUsuarioWindow(usuario);
            JFrame frame = new JFrame("Editar Usuario");
            frame.setContentPane(editarUsuarioWindow.getPanelPrincipal());
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.pack();
            frame.setVisible(true);
            frame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent e) {
                    cargarUsuariosEnTabla(usuarioDAO.obtenerUsuarios()); // Recargar la tabla después de editar
                }
            });
        } else {
            JOptionPane.showMessageDialog(null, "Error al obtener el usuario.");
        }
    }

    /**
     * Elimina un usuario seleccionado.
     */
    private void eliminarUsuario() {
        int selectedRow = tableUsuarios.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione un usuario para eliminar.");
            return;
        }

        int usuarioId = (int) tableUsuarios.getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar este usuario?");
        if (confirm == JOptionPane.YES_OPTION) {
            if (usuarioDAO.eliminarUsuario(usuarioId)) {
                JOptionPane.showMessageDialog(null, "Usuario eliminado con éxito.");
                cargarUsuariosEnTabla(usuarioDAO.obtenerUsuarios());
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar el usuario.");
            }
        }
    }

    public JPanel getPanelPrincipal() {
        return panelPrincipal;
    }
}
