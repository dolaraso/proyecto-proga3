package com.cybersentinels.vista;

import javax.swing.*;

public class MisPrestamosWindow {
    private JPanel panelMisPrestamos;
    private JTable tableMisPrestamos;
    private  JButton btnRegresar;

    public JPanel getPanelMisPrestamos() {
        return panelMisPrestamos;
    }
}
