package com.cybersentinels.vista;

import com.cybersentinels.dao.UsuarioDAO;
import com.cybersentinels.modelo.Usuario;

import javax.swing.*;

public class EditarUsuarioWindow {
    private JPanel panelPrincipal;
    private JTextField txtNombre;
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JComboBox<String> comboRol;
    private JButton btnGuardar;
    private JButton btnCancelar;

    private final UsuarioDAO usuarioDAO;
    private final Usuario usuario;

    public EditarUsuarioWindow(Usuario usuario) {
        this.usuario = usuario;
        usuarioDAO = new UsuarioDAO();
        initializeComponents();
        cargarDatosUsuario();

        btnGuardar.addActionListener(e -> guardarCambios());
        btnCancelar.addActionListener(e -> cerrarVentana());
    }

    private void initializeComponents() {
        txtNombre = new JTextField();
        txtUsuario = new JTextField();
        txtContrasena = new JPasswordField();
        comboRol = new JComboBox<>();
        btnGuardar = new JButton("Guardar");
        btnCancelar = new JButton("Cancelar");

        comboRol.addItem("Administrador");
        comboRol.addItem("Estudiante");
        comboRol.addItem("Profesor");
    }

    private void cargarDatosUsuario() {
        txtNombre.setText(usuario.getNombre());
        txtUsuario.setText(usuario.getUsuario());
        txtContrasena.setText(usuario.getContrasena());
        comboRol.setSelectedItem(usuario.getRol());
    }

    private void guardarCambios() {
        usuario.setNombre(txtNombre.getText().trim());
        usuario.setUsuario(txtUsuario.getText().trim());
        usuario.setContrasena(new String(txtContrasena.getPassword()).trim());
        usuario.setRol((String) comboRol.getSelectedItem());

        if (usuarioDAO.actualizarUsuario(usuario)) {
            JOptionPane.showMessageDialog(null, "Usuario actualizado correctamente.");
            cerrarVentana();
        } else {
            JOptionPane.showMessageDialog(null, "Error al actualizar el usuario.");
        }
    }

    private void cerrarVentana() {
        SwingUtilities.getWindowAncestor(panelPrincipal).dispose();
    }

    public JPanel getPanelPrincipal() {
        return panelPrincipal;
    }
}
