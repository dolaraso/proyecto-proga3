package com.cybersentinels.vista;

import com.cybersentinels.dao.UsuarioDAO;
import com.cybersentinels.modelo.Usuario;

import javax.swing.*;

public class AgregarUsuarioWindow {
    private JPanel panelPrincipal;
    private JTextField txtNombre;
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JComboBox<String> comboRol;
    private JButton btnGuardar;
    private JButton btnCancelar;

    private final UsuarioDAO usuarioDAO;

    public AgregarUsuarioWindow() {
        usuarioDAO = new UsuarioDAO();
        initializeComponents(); // Inicializa los componentes de la ventana
        configurarRoles();

        btnGuardar.addActionListener(e -> guardarUsuario());
        btnCancelar.addActionListener(e -> cerrarVentana());
    }

    private void initializeComponents() {
        panelPrincipal = new JPanel();
        txtNombre = new JTextField();
        txtUsuario = new JTextField();
        txtContrasena = new JPasswordField();
        comboRol = new JComboBox<>();
        btnGuardar = new JButton("Guardar");
        btnCancelar = new JButton("Cancelar");
    }

    private void configurarRoles() {
        comboRol.addItem("Administrador");
        comboRol.addItem("Estudiante");
        comboRol.addItem("Profesor");
    }

    private void guardarUsuario() {
        String nombre = txtNombre.getText().trim();
        String usuario = txtUsuario.getText().trim();
        String contrasena = new String(txtContrasena.getPassword()).trim();
        String rol = (String) comboRol.getSelectedItem();

        if (nombre.isEmpty() || usuario.isEmpty() || contrasena.isEmpty() || rol == null) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
            return;
        }

        Usuario nuevoUsuario = new Usuario(0, nombre, usuario, contrasena, rol);

        try {
            boolean guardado = usuarioDAO.agregarUsuario(nuevoUsuario);
            if (guardado) {
                JOptionPane.showMessageDialog(null, "Usuario agregado correctamente.");
                cerrarVentana();
            } else {
                JOptionPane.showMessageDialog(null, "Error al guardar el usuario.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al guardar en la base de datos: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void cerrarVentana() {
        SwingUtilities.getWindowAncestor(panelPrincipal).dispose();
    }

    public JPanel getPanelPrincipal() {
        return panelPrincipal;
    }
}
