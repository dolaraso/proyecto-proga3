package com.cybersentinels.vista;

import javax.swing.*;

public class UsuariosWindow {
    private JPanel panelUsuarios;
    private JTable tableUsuarios;
    private JButton btnAgregar;
    private JButton btnModificar;
    private JButton btnEliminar;

    public JPanel getPanelUsuarios() {
        return panelUsuarios;
    }
}
