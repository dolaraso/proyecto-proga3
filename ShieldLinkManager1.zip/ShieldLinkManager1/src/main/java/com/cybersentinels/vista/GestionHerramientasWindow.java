package com.cybersentinels.vista;

import com.cybersentinels.dao.HerramientaDAO;
import com.cybersentinels.modelo.Herramienta;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class GestionHerramientasWindow {
    private JPanel panelPrincipal;
    private JTable tableHerramientas;
    private JTextField txtBuscarNombre;
    private JButton btnBuscar;
    private JButton btnAgregar;
    private JButton btnModificar;
    private JButton btnEliminar;
    private JButton btnSelecionar;

    private final HerramientaDAO herramientaDAO;

    public GestionHerramientasWindow() {
        herramientaDAO = new HerramientaDAO();
        inicializarTabla();
        cargarHerramientasEnTabla();

        btnBuscar.addActionListener(e -> buscarHerramientasPorNombre());
        btnAgregar.addActionListener(e -> abrirVentanaAgregarHerramienta());
        btnModificar.addActionListener(e -> abrirVentanaModificarHerramienta());
        btnEliminar.addActionListener(e -> eliminarHerramientaSeleccionada());
    }

    private void inicializarTabla() {
        tableHerramientas.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{"ID", "Nombre", "Descripción", "Estado", "Tipo"}
        ));
    }

    private void cargarHerramientasEnTabla() {
        DefaultTableModel model = (DefaultTableModel) tableHerramientas.getModel();
        model.setRowCount(0); // Limpiar la tabla
        List<Herramienta> herramientas = herramientaDAO.obtenerHerramientas();
        for (Herramienta herramienta : herramientas) {
            model.addRow(new Object[]{
                    herramienta.getId(),
                    herramienta.getNombre(),
                    herramienta.getDescripcion(),
                    herramienta.getEstado(),
                    herramienta.getTipo()
            });
        }
    }

    private void buscarHerramientasPorNombre() {
        String nombre = txtBuscarNombre.getText().trim();
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese un nombre para buscar.");
            return;
        }

        Herramienta herramienta = herramientaDAO.obtenerHerramientaPorNombre(nombre);
        if (herramienta == null) {
            JOptionPane.showMessageDialog(null, "No se encontró una herramienta con el nombre: " + nombre);
        } else {
            DefaultTableModel model = (DefaultTableModel) tableHerramientas.getModel();
            model.setRowCount(0); // Limpiar la tabla
            model.addRow(new Object[]{
                    herramienta.getId(),
                    herramienta.getNombre(),
                    herramienta.getDescripcion(),
                    herramienta.getEstado(),
                    herramienta.getTipo()
            });
        }
    }

    private void abrirVentanaAgregarHerramienta() {
        JFrame frame = new JFrame("Agregar Herramienta");
        AgregarHerramientaWindow agregarHerramientaWindow = new AgregarHerramientaWindow(herramientaDAO);

        frame.setContentPane(agregarHerramientaWindow.getPanelPrincipal());
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                cargarHerramientasEnTabla();
            }
        });
    }

    private void abrirVentanaModificarHerramienta() {
        int selectedRow = tableHerramientas.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione una herramienta para modificar.");
            return;
        }

        // Obtener el nombre de la herramienta seleccionada en la columna 1 (Nombre)
        String herramientaNombre = (String) tableHerramientas.getValueAt(selectedRow, 1);
        Herramienta herramienta = herramientaDAO.obtenerHerramientaPorNombre(herramientaNombre);

        if (herramienta != null) {
            JFrame frame = new JFrame("Modificar Herramienta");
            ModificarHerramientaWindow modificarHerramientaWindow = new ModificarHerramientaWindow(herramienta, herramientaDAO);

            frame.setContentPane(modificarHerramientaWindow.getPanelPrincipal());
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            frame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent e) {
                    cargarHerramientasEnTabla();
                }
            });
        } else {
            JOptionPane.showMessageDialog(null, "No se pudo obtener la información de la herramienta seleccionada.");
        }
    }

    private void eliminarHerramientaSeleccionada() {
        int selectedRow = tableHerramientas.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione una herramienta para eliminar.");
            return;
        }

        // Obtén el nombre de la herramienta seleccionada
        String herramientaNombre = (String) tableHerramientas.getValueAt(selectedRow, 1);

        int confirm = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar la herramienta: " + herramientaNombre + "?");
        if (confirm == JOptionPane.YES_OPTION) {
            if (herramientaDAO.eliminarHerramientaPorNombre(herramientaNombre)) {
                JOptionPane.showMessageDialog(null, "Herramienta eliminada con éxito.");
                cargarHerramientasEnTabla();
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar la herramienta.");
            }
        }
    }

    public JPanel getPanelPrincipal() {
        return panelPrincipal;
    }
}
