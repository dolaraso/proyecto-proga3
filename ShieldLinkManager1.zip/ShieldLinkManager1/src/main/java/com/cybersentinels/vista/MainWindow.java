package com.cybersentinels.vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainWindow {
    private JPanel panelPrincipal;
    private JButton btnUsuarios;
    private JButton btnHerramientas;
    private JButton btnPrestamos;
    private JButton btnMantenimiento;
    private JLabel lblBienvenida;

    public MainWindow() {
        lblBienvenida.setText("Bienvenido al Sistema ShieldLink Manager");

        btnUsuarios.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Gestión de Usuarios");
                frame.setContentPane(new UsuariosWindow().getPanelUsuarios());
                frame.pack();
                frame.setVisible(true);
            }
        });

        btnHerramientas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Gestión de Herramientas");
                frame.setContentPane(new HerramientasWindow().getPanelHerramientas());
                frame.pack();
                frame.setVisible(true);
            }
        });

        btnPrestamos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Gestión de Préstamos y Reportes");
                frame.setContentPane(new PrestamosWindow().getPanelPrestamos());
                frame.pack();
                frame.setVisible(true);
            }
        });

        btnMantenimiento.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Gestión de Mantenimiento");
                frame.setContentPane(new MantenimientoWindow().getPanelMantenimiento());
                frame.pack();
                frame.setVisible(true);
            }
        });
    }

    public JPanel getPanelPrincipal() {
        return panelPrincipal;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("ShieldLink Manager");
        frame.setContentPane(new MainWindow().getPanelPrincipal());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
