package com.cybersentinels.controlador;

import com.cybersentinels.dao.HerramientaDAO;
import com.cybersentinels.modelo.Herramienta;

import java.util.List;

public class MantenimientoControlador {
    private HerramientaDAO herramientaDAO;

    public MantenimientoControlador() {
        this.herramientaDAO = new HerramientaDAO();
    }

    public boolean programarMantenimiento(int herramientaId) {
        Herramienta herramienta = herramientaDAO.obtenerHerramientaPorId(herramientaId);
        if (herramienta != null && herramienta.getEstado().equalsIgnoreCase("Disponible")) {
            herramienta.setEstado("Mantenimiento");
            return herramientaDAO.actualizarHerramienta(herramienta);
        }
        return false;
    }

    public List<Herramienta> obtenerHerramientasEnMantenimiento() {
        return herramientaDAO.obtenerHerramientasPorEstado("Mantenimiento");
    }

    public boolean finalizarMantenimiento(int herramientaId) {
        Herramienta herramienta = herramientaDAO.obtenerHerramientaPorId(herramientaId);
        if (herramienta != null && herramienta.getEstado().equalsIgnoreCase("Mantenimiento")) {
            herramienta.setEstado("Disponible");
            return herramientaDAO.actualizarHerramienta(herramienta);
        }
        return false;
    }
}
