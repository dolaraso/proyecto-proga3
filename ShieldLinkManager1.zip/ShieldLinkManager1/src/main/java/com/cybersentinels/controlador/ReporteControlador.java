package com.cybersentinels.controlador;

import com.cybersentinels.dao.PrestamoDAO;
import com.cybersentinels.dao.HerramientaDAO;
import com.cybersentinels.modelo.Prestamo;

import java.util.List;

public class ReporteControlador {
    private PrestamoDAO prestamoDAO;
    private HerramientaDAO herramientaDAO;

    public ReporteControlador() {
        prestamoDAO = new PrestamoDAO();
        herramientaDAO = new HerramientaDAO();
    }

    public List<Prestamo> generarReporteDePrestamos() {
        return prestamoDAO.obtenerPrestamosPorEstado("Activo");
    }

    public int contarPrestamosActivos() {
        List<Prestamo> prestamosActivos = prestamoDAO.obtenerPrestamosPorEstado("Activo");
        return prestamosActivos.size();
    }

    public int contarHerramientasEnMantenimiento() {
        return herramientaDAO.obtenerHerramientasPorEstado("Mantenimiento").size();
    }
}
