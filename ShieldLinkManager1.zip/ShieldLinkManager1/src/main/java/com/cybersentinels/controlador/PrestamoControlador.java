package com.cybersentinels.controlador;

import com.cybersentinels.dao.PrestamoDAO;
import com.cybersentinels.modelo.Prestamo;

import java.util.List;

public class PrestamoControlador {
    private final PrestamoDAO prestamoDAO = new PrestamoDAO();

    public void agregarPrestamo(Prestamo prestamo) {
        prestamoDAO.agregarPrestamo(prestamo);
    }

    public List<Prestamo> obtenerPrestamos() {
        return prestamoDAO.obtenerPrestamos();
    }

    public void actualizarPrestamo(Prestamo prestamo) {
        prestamoDAO.actualizarPrestamo(prestamo);
    }

    public void eliminarPrestamo(int id) {
        prestamoDAO.eliminarPrestamo(id);
    }

    public List<Prestamo> obtenerPrestamosPorUsuario(int usuarioId) {
        return prestamoDAO.obtenerPrestamosPorUsuario(usuarioId);
    }
}
