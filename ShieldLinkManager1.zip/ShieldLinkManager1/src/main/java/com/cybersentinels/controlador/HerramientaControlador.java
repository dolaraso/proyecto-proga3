package com.cybersentinels.controlador;

import com.cybersentinels.dao.HerramientaDAO;
import com.cybersentinels.modelo.Herramienta;

import java.util.List;

public class HerramientaControlador {
    private final HerramientaDAO herramientaDAO;

    public HerramientaControlador() {
        herramientaDAO = new HerramientaDAO();
    }

    public List<String> obtenerNombresHerramientasDisponibles() {
        return herramientaDAO.obtenerNombresHerramientasDisponibles();
    }

    public Herramienta obtenerHerramientaPorNombre(String nombre) {
        return herramientaDAO.obtenerHerramientaPorNombre(nombre);
    }

    public List<Herramienta> obtenerHerramientasPorEstado(String estado) {
        return herramientaDAO.obtenerHerramientasPorEstado(estado);
    }

    public boolean eliminarHerramienta(int id) {
        return herramientaDAO.eliminarHerramienta(id);
    }
}
