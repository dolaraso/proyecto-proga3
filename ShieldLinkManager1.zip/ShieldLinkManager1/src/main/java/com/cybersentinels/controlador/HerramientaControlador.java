package com.cybersentinels.controlador;

import com.cybersentinels.dao.HerramientaDAO;
import com.cybersentinels.modelo.Herramienta;

import java.util.List;

public class HerramientaControlador {
    private HerramientaDAO herramientaDAO;

    public HerramientaControlador() {
        herramientaDAO = new HerramientaDAO();
    }

    public boolean agregarHerramienta(String nombre, String descripcion, String estado, String tipo) {
        Herramienta herramienta = new Herramienta(0, nombre, descripcion, estado, tipo);
        return herramientaDAO.agregarHerramienta(herramienta);
    }

    public List<Herramienta> obtenerTodasHerramientas() {
        return herramientaDAO.obtenerHerramientas();
    }

    public boolean actualizarHerramienta(int id, String nombre, String descripcion, String estado, String tipo) {
        Herramienta herramienta = new Herramienta(id, nombre, descripcion, estado, tipo);
        return herramientaDAO.actualizarHerramienta(herramienta);
    }

    public boolean eliminarHerramienta(int id) {
        return herramientaDAO.eliminarHerramienta(id);
    }

    public Herramienta buscarHerramientaPorId(int id) {
        return herramientaDAO.obtenerHerramientaPorId(id);
    }
}
