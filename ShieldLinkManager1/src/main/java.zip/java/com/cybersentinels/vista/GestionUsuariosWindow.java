package com.cybersentinels.vista;

import com.cybersentinels.dao.UsuarioDAO;
import com.cybersentinels.modelo.Usuario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class GestionUsuariosWindow {
    private JPanel panelPrincipal;
    private JButton btnAgregarUsuario;
    private JButton btnEditarUsuario;
    private JButton btnEliminarUsuario;
    private JList<String> listaUsuarios;
    private DefaultListModel<String> usuariosModel;

    private final UsuarioDAO usuarioDAO;

    public GestionUsuariosWindow() {
        usuarioDAO = new UsuarioDAO();
        usuariosModel = new DefaultListModel<>();
        listaUsuarios.setModel(usuariosModel);

        cargarUsuarios();

        btnAgregarUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarUsuario();
            }
        });

        btnEditarUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarUsuario();
            }
        });

        btnEliminarUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarUsuario();
            }
        });
    }

    /**
     * Carga todos los usuarios de la base de datos en la lista visual.
     */
    private void cargarUsuarios() {
        usuariosModel.clear();
        List<Usuario> usuarios = usuarioDAO.obtenerUsuarios();
        for (Usuario usuario : usuarios) {
            usuariosModel.addElement(usuario.getId() + " - " + usuario.getNombre() + " (" + usuario.getRol() + ")");
        }
    }

    /**
     * Permite agregar un nuevo usuario con nombre y rol.
     */
    private void agregarUsuario() {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del usuario:");
        String usuario = JOptionPane.showInputDialog("Ingrese el nombre de usuario:");
        String contrasena = JOptionPane.showInputDialog("Ingrese la contraseña:");
        String rol = JOptionPane.showInputDialog("Ingrese el rol del usuario:");
        if (nombre != null && !nombre.isEmpty() &&
                usuario != null && !usuario.isEmpty() &&
                contrasena != null && !contrasena.isEmpty() &&
                rol != null && !rol.isEmpty()) {
            Usuario nuevoUsuario = new Usuario(0, nombre, usuario, contrasena, rol);
            if (usuarioDAO.agregarUsuario(nuevoUsuario)) {
                JOptionPane.showMessageDialog(null, "Usuario agregado correctamente.");
                cargarUsuarios();
            } else {
                JOptionPane.showMessageDialog(null, "Error al agregar el usuario.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Los campos no pueden estar vacíos.");
        }
    }

    /**
     * Permite editar un usuario existente por su ID.
     */
    private void editarUsuario() {
        String idStr = JOptionPane.showInputDialog("Ingrese el ID del usuario a editar:");
        if (idStr != null && !idStr.isEmpty()) {
            try {
                int id = Integer.parseInt(idStr);
                Usuario usuario = usuarioDAO.obtenerUsuarioPorId(id);
                if (usuario != null) {
                    String nuevoNombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre del usuario:", usuario.getNombre());
                    String nuevoRol = JOptionPane.showInputDialog("Ingrese el nuevo rol del usuario:", usuario.getRol());
                    if (nuevoNombre != null && nuevoRol != null && !nuevoNombre.isEmpty() && !nuevoRol.isEmpty()) {
                        usuario.setNombre(nuevoNombre);
                        usuario.setRol(nuevoRol);
                        if (usuarioDAO.actualizarUsuario(usuario)) {
                            JOptionPane.showMessageDialog(null, "Usuario editado correctamente.");
                            cargarUsuarios();
                        } else {
                            JOptionPane.showMessageDialog(null, "Error al editar el usuario.");
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Usuario no encontrado.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "El ID debe ser un número.");
            }
        }
    }

    /**
     * Permite eliminar un usuario existente por su ID.
     */
    private void eliminarUsuario() {
        String idStr = JOptionPane.showInputDialog("Ingrese el ID del usuario a eliminar:");
        if (idStr != null && !idStr.isEmpty()) {
            try {
                int id = Integer.parseInt(idStr);
                if (usuarioDAO.eliminarUsuario(id)) {
                    JOptionPane.showMessageDialog(null, "Usuario eliminado correctamente.");
                    cargarUsuarios();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al eliminar el usuario.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "El ID debe ser un número.");
            }
        }
    }

    /**
     * Retorna el panel principal para integrarlo con otras ventanas.
     */
    public JPanel getPanelPrincipal() {
        return panelPrincipal;
    }
}
