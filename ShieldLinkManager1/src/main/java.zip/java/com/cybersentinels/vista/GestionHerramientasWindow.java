package com.cybersentinels.vista;

import com.cybersentinels.dao.HerramientaDAO;
import com.cybersentinels.modelo.Herramienta;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class GestionHerramientasWindow {
    private JPanel panelPrincipal;
    private JButton btnAgregarHerramienta;
    private JButton btnEditarHerramienta;
    private JButton btnEliminarHerramienta;
    private JList<String> listaHerramientas;
    private DefaultListModel<String> herramientasModel;

    private final HerramientaDAO herramientaDAO;

    public GestionHerramientasWindow() {
        herramientaDAO = new HerramientaDAO();
        herramientasModel = new DefaultListModel<>();
        listaHerramientas.setModel(herramientasModel);

        cargarHerramientas();

        btnAgregarHerramienta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarHerramienta();
            }
        });

        btnEditarHerramienta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarHerramienta();
            }
        });

        btnEliminarHerramienta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarHerramienta();
            }
        });
    }

    private void cargarHerramientas() {
        herramientasModel.clear();
        List<Herramienta> herramientas = herramientaDAO.obtenerHerramientas();
        for (Herramienta herramienta : herramientas) {
            herramientasModel.addElement(herramienta.getId() + " - " + herramienta.getNombre() + " (" + herramienta.getEstado() + ")");
        }
    }

    private void agregarHerramienta() {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre de la herramienta:");
        String estado = JOptionPane.showInputDialog("Ingrese el estado de la herramienta:");
        if (nombre != null && !nombre.isEmpty() && estado != null && !estado.isEmpty()) {
            Herramienta herramienta = new Herramienta(0, nombre, estado);
            if (herramientaDAO.agregarHerramienta(herramienta)) {
                JOptionPane.showMessageDialog(null, "Herramienta agregada correctamente.");
                cargarHerramientas();
            } else {
                JOptionPane.showMessageDialog(null, "Error al agregar la herramienta.");
            }
        }
    }

    private void editarHerramienta() {
        String idStr = JOptionPane.showInputDialog("Ingrese el ID de la herramienta a editar:");
        if (idStr != null && !idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            Herramienta herramienta = herramientaDAO.obtenerHerramientaPorId(id);
            if (herramienta != null) {
                String nuevoNombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre de la herramienta:", herramienta.getNombre());
                String nuevoEstado = JOptionPane.showInputDialog("Ingrese el nuevo estado de la herramienta:", herramienta.getEstado());
                if (nuevoNombre != null && nuevoEstado != null) {
                    herramienta.setNombre(nuevoNombre);
                    herramienta.setEstado(nuevoEstado);
                    if (herramientaDAO.actualizarHerramienta(herramienta)) {
                        JOptionPane.showMessageDialog(null, "Herramienta editada correctamente.");
                        cargarHerramientas();
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al editar la herramienta.");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Herramienta no encontrada.");
            }
        }
    }

    private void eliminarHerramienta() {
        String idStr = JOptionPane.showInputDialog("Ingrese el ID de la herramienta a eliminar:");
        if (idStr != null && !idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            if (herramientaDAO.eliminarHerramienta(id)) {
                JOptionPane.showMessageDialog(null, "Herramienta eliminada correctamente.");
                cargarHerramientas();
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar la herramienta.");
            }
        }
    }

    public JPanel getPanelPrincipal() {
        return panelPrincipal;
    }
}
