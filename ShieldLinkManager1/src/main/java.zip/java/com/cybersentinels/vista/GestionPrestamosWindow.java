package com.cybersentinels.vista;

import com.cybersentinels.dao.PrestamoDAO;
import com.cybersentinels.modelo.Prestamo;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class GestionPrestamosWindow {
    private JPanel panelPrincipal;
    private JButton btnAgregarPrestamo;
    private JButton btnEditarPrestamo;
    private JButton btnEliminarPrestamo;
    private JList<String> listaPrestamos;
    private DefaultListModel<String> prestamosModel;

    private final PrestamoDAO prestamoDAO;

    public GestionPrestamosWindow() {
        prestamoDAO = new PrestamoDAO();
        prestamosModel = new DefaultListModel<>();
        listaPrestamos.setModel(prestamosModel);

        cargarPrestamos();

        btnAgregarPrestamo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarPrestamo();
            }
        });

        btnEditarPrestamo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarPrestamo();
            }
        });

        btnEliminarPrestamo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarPrestamo();
            }
        });
    }

    private void cargarPrestamos() {
        prestamosModel.clear();
        List<Prestamo> prestamos = prestamoDAO.obtenerPrestamos();
        for (Prestamo prestamo : prestamos) {
            prestamosModel.addElement(prestamo.getId() + " - Usuario: " + prestamo.getUsuarioId() +
                    ", Herramienta: " + prestamo.getHerramientaId() + ", Estado: " + prestamo.getEstado());
        }
    }

    private void agregarPrestamo() {
        try {
            String usuarioIdStr = JOptionPane.showInputDialog("Ingrese el ID del usuario:");
            String herramientaIdStr = JOptionPane.showInputDialog("Ingrese el ID de la herramienta:");
            String estado = JOptionPane.showInputDialog("Ingrese el estado del préstamo:");

            if (usuarioIdStr != null && herramientaIdStr != null && estado != null &&
                    !usuarioIdStr.isEmpty() && !herramientaIdStr.isEmpty() && !estado.isEmpty()) {
                int usuarioId = Integer.parseInt(usuarioIdStr);
                int herramientaId = Integer.parseInt(herramientaIdStr);
                Prestamo prestamo = new Prestamo(0, usuarioId, herramientaId, estado);

                if (prestamoDAO.agregarPrestamo(prestamo)) {
                    JOptionPane.showMessageDialog(null, "Préstamo agregado correctamente.");
                    cargarPrestamos();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al agregar el préstamo.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los IDs deben ser numéricos.");
        }
    }

    private void editarPrestamo() {
        try {
            String idStr = JOptionPane.showInputDialog("Ingrese el ID del préstamo a editar:");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);
                Prestamo prestamo = prestamoDAO.obtenerPrestamoPorId(id);

                if (prestamo != null) {
                    String nuevoEstado = JOptionPane.showInputDialog("Ingrese el nuevo estado del préstamo:", prestamo.getEstado());
                    if (nuevoEstado != null && !nuevoEstado.isEmpty()) {
                        prestamo.setEstado(nuevoEstado);

                        if (prestamoDAO.actualizarPrestamo(prestamo)) {
                            JOptionPane.showMessageDialog(null, "Préstamo actualizado correctamente.");
                            cargarPrestamos();
                        } else {
                            JOptionPane.showMessageDialog(null, "Error al actualizar el préstamo.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "El estado no puede estar vacío.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Préstamo no encontrado.");
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID debe ser numérico.");
        }
    }

    private void eliminarPrestamo() {
        try {
            String idStr = JOptionPane.showInputDialog("Ingrese el ID del préstamo a eliminar:");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);

                if (prestamoDAO.eliminarPrestamo(id)) {
                    JOptionPane.showMessageDialog(null, "Préstamo eliminado correctamente.");
                    cargarPrestamos();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al eliminar el préstamo.");
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID debe ser numérico.");
        }
    }

    public JPanel getPanelPrincipal() {
        return panelPrincipal;
    }
}
